#!/usr/bin/env bash
set -euo pipefail
backup_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$backup_dir/config-dir" ]] || { echo 'Run restore.sh from the backup directory printed by apply.sh.' >&2; exit 1; }
IFS= read -r config_dir < "$backup_dir/config-dir"
for relative_path in kdeglobals Kvantum/kvantum.kvconfig; do
  target="$config_dir/$relative_path"
  [[ ! -L "$target" ]] || { echo "Refusing to replace symlink: $target" >&2; exit 1; }
  if [[ -f "$backup_dir/files/$relative_path" ]]; then
    mkdir -p -- "$(dirname -- "$target")"
    cp -p -- "$backup_dir/files/$relative_path" "$target"
  else
    rm -f -- "$target"
  fi
done
printf 'Original KDE and Kvantum settings restored. Log out and back in.\n'
printf 'Installed BlackViolet theme files remain available but are no longer selected.\n'
