Black Violet — KDE Plasma + Kvantum

Based on the supplied 1337.colors and KvSimplicityDark files by Tsu Jan.
Original theme geometry, SVG IDs and semantic warning/error colors are preserved.

Apply on your Arch machine, inside your normal KDE user session:
  bash apply.sh
No sudo. No package installation. No kernel, driver, panel-layout or login-screen changes.
The script refuses to overwrite an existing BlackViolet installation.
It backs up kdeglobals and Kvantum/kvantum.kvconfig before selecting the theme.
If application fails after copying files, use the printed restore command.
Close and reopen applications; log out and back in for a complete refresh.

Rollback:
Run the exact backup-directory restore.sh command printed by apply.sh.
This restores the two complete settings files, including any older preferences.
Changes made to those files after applying will also be undone.
Installed theme files remain on disk for future use.

Panel/menu:
Current Breeze Dark desktop theme may keep its own colors.
If it remains gray, use System Settings > Colors & Themes > Plasma Style:
select Breeze, which can follow the color scheme. Avoid Global Theme application,
which can change layouts. To undo this optional manual step, select Breeze Dark.
For KDE accent selection, select 'From current color scheme' or #A78BFA if needed.

Terminal:
Terminal backgrounds are separate from the KDE color scheme. Kitty and Konsole
are deliberately not modified without inspecting their existing configuration.
Set background #0D0D10, foreground #E2DFE8 and selection #35254D in their theme settings.
GTK/libadwaita, browser content and third-party applications may use separate themes.

Validation performed in the cloud:
SVG parses as XML and retains all element IDs.
KDE color values are valid RGB; shell scripts pass bash syntax validation.
Visual rendering and live KDE application have NOT been tested here.
After applying, check Dolphin lists, dialogs, disabled buttons, selection text,
launcher/menu, and active/inactive windows; send a screenshot for refinement.
