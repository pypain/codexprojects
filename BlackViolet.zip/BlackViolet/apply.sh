#!/usr/bin/env bash
set -euo pipefail
bundle_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
config_dir=${XDG_CONFIG_HOME:-"$HOME/.config"}
data_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}
for command_name in plasma-apply-colorscheme kwriteconfig6; do
  command -v "$command_name" >/dev/null || { echo "Missing: $command_name" >&2; exit 1; }
done
for filename in BlackViolet.kvconfig BlackViolet.svg BlackViolet.colors; do
  test -f "$bundle_dir/$filename"
done
for target in "$config_dir/Kvantum/BlackViolet" "$data_dir/color-schemes/BlackViolet.colors"; do
  if [[ -e "$target" || -L "$target" ]]; then
    echo "Already exists; refusing to overwrite: $target" >&2
    exit 1
  fi
done
mkdir -p -- "$data_dir/black-violet-backups"
backup_dir=$(mktemp -d "$data_dir/black-violet-backups/backup-XXXXXXXX")
chmod 700 "$backup_dir"
printf '%s\n' "$config_dir" > "$backup_dir/config-dir"
for relative_path in kdeglobals Kvantum/kvantum.kvconfig; do
  if [[ -L "$config_dir/$relative_path" ]]; then
    echo "Symlinked settings require manual backup: $relative_path" >&2
    exit 1
  fi
  if [[ -e "$config_dir/$relative_path" ]]; then
    mkdir -p -- "$backup_dir/files/$(dirname -- "$relative_path")"
    cp -p -- "$config_dir/$relative_path" "$backup_dir/files/$relative_path"
  fi
done
cp -- "$bundle_dir/restore.sh" "$backup_dir/restore.sh"
mkdir -p -- "$config_dir/Kvantum/BlackViolet" "$data_dir/color-schemes"
cp -- "$bundle_dir/BlackViolet.kvconfig" "$bundle_dir/BlackViolet.svg" "$config_dir/Kvantum/BlackViolet/"
cp -- "$bundle_dir/BlackViolet.colors" "$data_dir/color-schemes/BlackViolet.colors"
printf 'Backup and rollback: bash "%s/restore.sh"\n' "$backup_dir"
plasma-apply-colorscheme BlackViolet
kwriteconfig6 --file kdeglobals --group General --key AccentColor '167,139,250'
kwriteconfig6 --file kdeglobals --group KDE --key widgetStyle kvantum
kwriteconfig6 --file "$config_dir/Kvantum/kvantum.kvconfig" --group General --key theme BlackViolet
printf '\nApplied. Close and reopen applications. Log out and back in to refresh all components.\n'
